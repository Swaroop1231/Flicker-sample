//
//  JSONFlickrViewController.m
//  JSONFlickr
//
//  Created by John on 8/21/09.
//  Copyright iPhoneDeveloperTips.com 2009. All rights reserved.
//

#import "JSONFlickrViewController.h"
#import "JSON.h"
#import<QuartzCore/QuartzCore.h>

#define debug(format, ...) CFShow([NSString stringWithFormat:format, ## __VA_ARGS__]);

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Private interface definitions
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
@interface JSONFlickrViewController(private)
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
- (void)searchFlickrPhotos:(NSString *)text;
@end


// Replace with your Flickr key
NSString *const FlickrAPIKey = @"6d08a9afaa64c26717ef30455ec37046";

@implementation JSONFlickrViewController

/**************************************************************************
*
* Private implementation section
*
**************************************************************************/

#pragma mark -
#pragma mark Private Methods

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data 
{
  // Store incoming data into a string
	NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];

 // debug(@"jsonString: %@", jsonString);

  // Create a dictionary from the JSON string
	NSDictionary *results = [jsonString JSONValue];
	
  // Build an array from the dictionary for easy access to each entry
	NSArray *photos = [[results objectForKey:@"photos"] objectForKey:@"photo"];
  
  // Loop through each entry in the dictionary...
	for (NSDictionary *photo in photos)
  {
    // Get title of the image
		NSString *title = [photo objectForKey:@"title"];
    
    // Save the title to the photo titles array
		[photoTitles addObject:(title.length > 0 ? title : @"Untitled")];
		
    // Build the URL to where the image is stored (see the Flickr API)
    // In the format http://farmX.static.flickr.com/server/id/secret
    // Notice the "_s" which requests a "small" image 75 x 75 pixels
		NSString *photoURLString = [NSString stringWithFormat:@"http://farm%@.static.flickr.com/%@/%@_%@_s.jpg", [photo objectForKey:@"farm"], [photo objectForKey:@"server"], [photo objectForKey:@"id"], [photo objectForKey:@"secret"]];

    //debug(@"photoURLString: %@", photoURLString);

    // The performance (scrolling) of the table will be much better if we
    // build an array of the image data here, and then add this data as
    // the cell.image value (see cellForRowAtIndexPath:)
		[photoSmallImageData addObject:[NSData dataWithContentsOfURL:[NSURL URLWithString:photoURLString]]];

    // Build and save the URL to the large image so we can zoom
    // in on the image if requested
		photoURLString = [NSString stringWithFormat:@"http://farm%@.static.flickr.com/%@/%@_%@_m.jpg", [photo objectForKey:@"farm"], [photo objectForKey:@"server"], [photo objectForKey:@"id"], [photo objectForKey:@"secret"]];
		[photoURLsLargeImage addObject:[NSURL URLWithString:photoURLString]];        
    
    //debug(@"photoURLsLareImage: %@\n\n", photoURLString);
	}
  
  // Update the table with data
  [theTableView reloadData];


}

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
-(void)searchFlickrPhotos:(NSString *)text
{
  // Build the string to call the Flickr API
	NSString *urlString = [NSString stringWithFormat:@"http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=%@&tags=%@&per_page=15&format=json&nojsoncallback=1", FlickrAPIKey, text];
  
  // Create NSURL string from formatted string
	NSURL *url = [NSURL URLWithString:urlString];

  // Setup and start async download
  NSURLRequest *request = [[NSURLRequest alloc] initWithURL: url];
  NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];

    
}

/**************************************************************************
*
* Class implementation section
*
**************************************************************************/

#pragma mark -
#pragma mark Initialization

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
- (id)init
{
  if (self = [super init])
  {
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];

    
     // Create table view
    theTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 460)];
    [theTableView setDelegate:self];
    [theTableView setDataSource:self];
    [theTableView setRowHeight:80];
    [self.view addSubview:theTableView];
    [theTableView setBackgroundColor:[UIColor grayColor]];
    [theTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
     

      
    /*  self.scrollview=[[UIScrollView alloc] initWithFrame:CGRectMake(0,0,320,460)];
      [self.scrollview setDelegate:self];
      [self.view addSubview:self.scrollview];
      [self.scrollview setBackgroundColor:[UIColor grayColor]];

      [self createScrollView];
     */
    // Initialize our arrays
		photoTitles = [[NSMutableArray alloc] init];
		photoSmallImageData = [[NSMutableArray alloc] init];
		photoURLsLargeImage = [[NSMutableArray alloc] init];
    
    // Notice that I am hard-coding the search tag at this point (@"iPhone")    
    [self searchFlickrPhotos:@"iPhone"];

  }
	return self;

}

#pragma mark -
#pragma mark Table Mgmt

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [photoTitles count];
}

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cachedCell"];
  if (cell == nil)
    cell = [[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"cachedCell"];

#if __IPHONE_3_0
  cell.textLabel.text = [photoTitles objectAtIndex:indexPath.row];
  cell.textLabel.font = [UIFont systemFontOfSize:13.0];
#else
  cell.text = [photoTitles objectAtIndex:indexPath.row];
  cell.font = [UIFont systemFontOfSize:13.0];
#endif
	
	NSData *imageData = [photoSmallImageData objectAtIndex:indexPath.row];

#if __IPHONE_3_0
  cell.imageView.image = [UIImage imageWithData:imageData];
#else
	cell.image = [UIImage imageWithData:imageData];
#endif
	
	return cell;
}

#pragma mark -
#pragma mark Cleanup

/*-------------------------------------------------------------
*
*------------------------------------------------------------*/
-(void)createScrollView
{

    for (UIView * subView in [self.scrollview subviews])
    {
        [subView removeFromSuperview];
    }
    self.scrollview.frame=CGRectMake(0, 0, 320, 460);
    int x=13;
    int y=13;
    NSLog(@"the count og phototitles%d",[photoSmallImageData count]);
    for (int i =0;i<[photoTitles count]; i++)
    {

        UIView *aView = [[UIView alloc] initWithFrame:CGRectMake(x, y, 84, 84)];
        aView.backgroundColor=[UIColor grayColor];
        aView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleRightMargin;
        aView.tag = i;
        UIImageView *coverImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,aView.frame.size.width,84)];



        coverImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleRightMargin;

        // [coverImageView setImageWithURL:[NSURL URLWithString:bobj.thumbimg_url] placeholderImage:[UIImage imageNamed:@"ipartygram_no_images.png"]];

        aView.layer.cornerRadius = 5.0;
        aView.layer.masksToBounds =YES;



        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame=CGRectMake(0,0,aView.frame.size.width,84);

        [button.layer setBorderWidth:2.0];
        [button.layer setCornerRadius:1.0];
        [button.layer setBorderColor:[[UIColor colorWithWhite:0.3 alpha:0.7] CGColor]];

        [button setImage:[UIImage imageNamed:[photoTitles objectAtIndex:i]] forState:UIControlStateNormal];


        button.tag=i;
        [button addTarget:self action:@selector(colorBtnPressed:) forControlEvents:UIControlEventTouchUpInside];

        button.layer.cornerRadius = 5.0;
        button.layer.masksToBounds =YES;


        [aView addSubview:coverImageView];

        [aView addSubview:button];




        [self.scrollview addSubview:aView];

        if((i+1)%3==0)
        {
            x=13;
            y=y+100;

        }
        else if((i+1)%3 > 0)
        {
            x=x+102;
        }

    }

    if([photoTitles count]%3==0){
        self.scrollview.contentSize=CGSizeMake(self.scrollview.frame.size.width, y+150);
    }
    else if([photoTitles count]%3 > 0){
        self.scrollview.contentSize=CGSizeMake(self.scrollview.frame.size.width, y+200);
    }

}

@end
